# **********************************************************
# Copyright 2005-2015 VMware, Inc.  All rights reserved. -- VMware Confidential
# **********************************************************

# In VmomiSupport, to support dynamic type loading, all the data types are wrapped around
# using a meta type which can intercept attribute access and load the necessary nested
# classes. This can be implemented only in python 2.5 version or more.
import sys
if sys.version_info < (2,5):
   sys.stderr.write("You need Python 2.5 or later to import pyVmomi module\n")
   sys.exit(1)

from . import VmomiSupport
from . import CoreTypes
from . import QueryTypes
try:
   from . import ReflectTypes
except ImportError:
   pass
try:
   from . import ServerObjects
except ImportError:
   pass
try:
   from . import InternalServerObjects
except ImportError:
   pass

# Import all the known product-specific types
# XXX: Make this search the package for types?
try:
   from . import DrObjects
except ImportError:
   pass

try:
   from . import DrextObjects
except ImportError:
   pass

try:
   from . import HbrReplicaTypes
except ImportError:
   pass
try:
   from . import HbrAgentTypes
except ImportError:
   pass
try:
   from . import HbrCascadeAgentTypes
except ImportError:
   pass
try:
   from . import HbrKeyServerTypes
except ImportError:
   pass
try:
   from . import HmsObjects
except ImportError:
   pass
try:
   from . import HostdObjects
except ImportError:
   pass
try:
   from . import VpxObjects
except ImportError:
   pass
try:
   from . import VorbTypes
except ImportError:
   pass
try:
   from . import DodoTypes
except ImportError:
   pass
try:
   from . import VmwauthproxyTypes
except ImportError:
   pass
try:
   from . import DmsTypes
except ImportError:
   pass
try:
   from . import OmsTypes
except ImportError:
   pass
try:
   from . import HmoTypes
except ImportError:
   pass
try:
   from . import CimsfccTypes
except ImportError:
   pass
try:
   from . import TaskupdaterTypes
except ImportError:
   pass
try:
   from . import ImgFactTypes
except ImportError:
   pass
try:
   from . import ImgBldTypes
except ImportError:
   pass
try:
   from . import VpxapiTypes
except ImportError:
   pass
try:
   from . import CsiObjects
except ImportError:
   pass

try:
   from . import HostdTypes
except ImportError:
   pass

try:
   from . import TaggingObjects
except ImportError:
   pass

try:
   from . import NfcTypes
except ImportError:
   pass

try:
   from . import SmsObjects
except ImportError:
   pass

try:
   from . import SpsObjects
except ImportError:
   pass

try:
   from . import DataserviceObjects
except ImportError:
   pass

# Start of update manager specific types
try:
   from . import IntegrityObjects
except ImportError:
   pass

try:
   from . import SysimageObjects
except ImportError:
   pass
# End of update manager specific types

try:
   from . import RbdTypes
except ImportError:
   pass

# Import Profile based management specific VMODL
try:
   from . import PbmObjects
except ImportError:
   pass

try:
   from . import CisLicenseTypes
except ImportError:
   pass

try:
   from . import LegacyLicenseTypes
except ImportError:
   pass

try:
   from . import TestTypes
except ImportError:
   pass

try:
   from . import SsoTypes
except ImportError:
   pass

try:
   from . import CisCmTypes
except ImportError:
    pass

try:
   from . import CisDataTypes
except ImportError:
   pass

try:
   from . import DataserviceTypes
except ImportError:
   pass

try:
   from . import LookupTypes
except ImportError:
   pass


# All data object types and fault types have DynamicData as an ancestor
# As well load it proactively.
# Note: This should be done before importing SoapAdapter as it uses
# some fault types
VmomiSupport.GetVmodlType("vmodl.DynamicData")

from .SoapAdapter import SoapStubAdapter, StubAdapterBase, SoapCmdStubAdapter, \
    SessionOrientedStub, ThumbprintMismatchException

types = VmomiSupport.types

# This will allow files to use Create** functions
# directly from pyVmomi
CreateEnumType = VmomiSupport.CreateEnumType
CreateDataType = VmomiSupport.CreateDataType
CreateManagedType = VmomiSupport.CreateManagedType

# For all the top level names, creating a LazyModule object
# in the global namespace of pyVmomi. Files can just import the
# top level namespace and we will figure out what to load and when
# Examples:
# ALLOWED: from pyVmomi import vim
# NOT ALLOWED: from pyVmomi import vim.host
_globals = globals()
for name in VmomiSupport._topLevelNames:
   upperCaseName = VmomiSupport.Capitalize(name)
   obj = VmomiSupport.LazyModule(name)
   _globals[name] = obj
   if VmomiSupport._allowCapitalizedNames:
      _globals[upperCaseName] = obj
   if not hasattr(VmomiSupport.types, name):
      setattr(VmomiSupport.types, name, obj)
      if VmomiSupport._allowCapitalizedNames:
         setattr(VmomiSupport.types, upperCaseName, obj)
del _globals
